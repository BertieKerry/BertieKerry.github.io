Hello,
This is my sailing simulator simulator version 1? 2.12?
Its getting good enough now that i reckon it will be replacing the americas cup in the 
coming years. Thats all.

a/d - left right
up/down - sail in out

BK